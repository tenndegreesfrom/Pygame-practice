
'''
Homework #4
-----------
Announced: Saturday, February 19, 2022
Due: Thursday, February 24, 2022

The program MUST read from a text file containing words on your hard-drive. Download the attached hw4.txt file to a suitable location on your hard drive for processing.
The hw4.txt file MUST be placed into a sub-folder called "data" in the directory where your Python program resides. 
You MUST use path from the os module to access the data as we did in class.
The word to guess at MUST be randomly selected. 
Words containing special characters (apostrophes, commas, periods etc) are not allowed . If a word containing these characters is randomly selected then select a different one.
Words selected MUST be longer than 3 characters.
The program should show the wrong guesses (Missed letters) and the ones that you got correct.
Underscores should be in place of the letters that have not been guessed.
As a bonus, the user should asked if she/he wants to start again.'''

#Stages
import re
import random
hangman_word_list = list()
gameplay_length = list()
deadman = 0

#Read text file from filepath/data
from os import path
filepath = path.join(path.dirname(__file__),'data','hw4.txt')

try:
    fp = open('hw4.txt',encoding="utf8")  #file is encoded for some reason, this helped. Source: https://stackoverflow.com/questions/9233027/unicodedecodeerror-charmap-codec-cant-decode-byte-x-in-position-y-character 
    lines = fp.read()
    fp.close()
except IOError as e:
    print('Can\'t open file', e)
#File is read.

#Defining graphics
hm_phase = ['''
                    __________
                    |         |
                    |         |
                              |
                              |
                              |
                              |
                           ___|___ ''',
            '''
                    __________ 
                    |         |
                    |         |
                ()(o_o)()     |
                              |
                              |
                              |
                           ___|___ ''',
            '''
                    __________ 
                    |         |
                    |         |
                ()(o_o)()     |
                  /           |
                              |
                              |
                           ___|___ ''',

            '''
                    __________ 
                    |         |
                    |         |
                ()(o_o)()     |
                  /| |        |
                              |
                              |
                           ___|___ ''',
            '''
                    __________ 
                    |         |
                    |         |
                ()(o_o)()     |
                  /| |\       |
                              |
                              |
                           ___|___ ''',

            '''
                    __________ 
                    |         |
                    |         |
                ()(o_o)()     |
                  /| |\       |
                   /          |
                              |
                           ___|___ ''',

            '''
                    __________ 
                    |         |
                    |         |
                ()(o_o)()     |
                  /| |\       |
                   / \        |
                              |
                           ___|___ ''',

            '''
                    __________ 
                    |         |
                    |         |
                ()(x_x)()     |
                  /| |\       |
                   / \        |
                              |
                           ___|___ ''']

modified_lines = (re.sub('[^a-zA-Z\s]','',lines))
lower_mod_lines = modified_lines.lower().split()
#print(lower_mod_lines)

#Conditional: Word > 3 letters. If no, select another word - consider list comprehension, remember to split on spaces
for word in lower_mod_lines:
    if len(word) > 3:
        hangman_word_list.append(word)
    else:
        pass

#Ask the user if they would like to play for the first time.
play_status = input('Would you like to play hangman?  Select Y or N: ')
play_status2 = play_status.upper()

#Select word. 
gameplay_word = random.choice(hangman_word_list)
word_length = len(gameplay_word)
blank_word = str(word_length * ('_'));
wrong_letters = list()

def hangman_game(play_status2):
    blank_word = str(word_length * ('_'));
    print(blank_word)
    deadman = 0 
    while blank_word != gameplay_word and deadman <=6:
        user_guess = input('Guess a letter.  Use lower case letters only: ')
        user_guess2 = user_guess.lower()
        if user_guess2 in gameplay_word:
            for i in range(word_length):
                if (user_guess2 == gameplay_word[i]):
                    blank_word = blank_word[:i] + user_guess + blank_word[i+1:]
                        
            print(blank_word)
            print('You found a letter!')
            print(f'Incorrect letters tried: {wrong_letters}')
            print(hm_phase[deadman])
        else:
            print(blank_word)
            print(f'{user_guess2} is not found in the word.')
            wrong_letters.append(user_guess)
            print(f'Incorrect letters tried: {wrong_letters}')
            print(hm_phase[deadman+1])
            deadman = deadman + 1

    if deadman == 7:
        print('High, low, hang Jack - ()(x_X)() Oh no!')
        print(f'The word was: {gameplay_word}.')
    else:
         print(f'Congratulations ()(o_O)(), you\'ve saved Jack and won the game with the word: {gameplay_word}!')   
        



while play_status2 == 'Y':
    gameplay_word = random.choice(hangman_word_list)
    word_length = len(gameplay_word)
    print(f'The word has {word_length} letters.  Good luck!')
    blank_word = str(word_length * ('_'));
    wrong_letters = list()
    hangman_game(play_status2)
    play_status = input('Would you like to play again? Select Y or N: ')
    play_status2 = play_status.upper()

print('Thanks for playing. Goodbye!')
    


